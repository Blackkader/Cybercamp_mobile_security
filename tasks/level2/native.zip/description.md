Including some c or c++ in mobile dev , is quite hard :( 

**Author :[Blackkader](https://github.com/Blackkader)**
